﻿namespace _14.CatLady
{
    public class Cat
    {
        public string name;

        
    }
}
