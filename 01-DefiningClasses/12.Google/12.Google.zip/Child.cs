﻿namespace _12.Google
{
    public class Child
    {
        public string childName;
        public string childBirthday;

        public Child(string childName, string childBirthday)
        {
            this.childName = childName;
            this.childBirthday = childBirthday;
        }
    }
}
