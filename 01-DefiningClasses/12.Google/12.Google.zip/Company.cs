﻿namespace _12.Google
{
    public class Company
    {
        public string companyName;
        public string companyDepartment;
        public decimal salary;

    }
}
