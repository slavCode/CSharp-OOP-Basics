﻿namespace _12.Google
{
    public class Car
    {
        public string carModel;
        public int carSpeed;
    }
}
