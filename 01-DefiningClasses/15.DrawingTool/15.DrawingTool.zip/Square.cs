﻿namespace _15.DrawingTool
{
    public class Square : CorDraw
    {
        public Square(int length)
        {
            this.width = length;
            this.height = length;
        }
    }
}
